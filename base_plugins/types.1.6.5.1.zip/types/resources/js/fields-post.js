jQuery(document).ready(function(){
    /*
     * 
     * 
     * 
     * This should be triggered in icl_editor_addon_plugin.js
     * TODO 1.3 Remove
     */
    // Set active editor
//    window.wpcfActiveEditor = false;
//    jQuery('.wpcf-wysiwyg .editor_addon_wrapper .item, #postdivrich .editor_addon_wrapper .item').click(function(){
//        window.wpcfActiveEditor = jQuery(this).parents('.wpcf-wysiwyg, #postdivrich').find('textarea').attr('id');
//    });
});